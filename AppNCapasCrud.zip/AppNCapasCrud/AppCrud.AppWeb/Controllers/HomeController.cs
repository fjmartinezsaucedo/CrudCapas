﻿using AppCrud.AppWeb.Models;
using AppCrud.AppWeb.Models.ViewModels;
using AppCrud.Models;
using AppCrud.Negocio.Servicio;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace AppCrud.AppWeb.Controllers
{
    public class HomeController : Controller
    {
        private readonly IClienteService _clienteService;

        public HomeController(IClienteService clienteServi)
        {
            _clienteService = clienteServi;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public async Task <IActionResult> Consulta()
        {
            IQueryable<Cliente> queryClienteSQL = await _clienteService.ObtenerTodos();

            List<VMCliente> lista = queryClienteSQL
                .Select(c => new VMCliente() {
                    IdCliente = c.IdCliente,
                    Nombre = c.Nombre,
                    ApellidoPaterno = c.ApellidoPaterno,
                    ApellidoMaterno = c.ApellidoMaterno,
                    CantidadPrestada = c.CantidadPrestada,
                    Telefono = c.Telefono,
                    Email = c.Email,
                    FechaPrestamo = c.FechaPrestamo,
                    DiaCobro = c.DiaCobro,
                    MesPrestamo = c.MesPrestamo,
                    Intereses = c.Intereses,
                }).ToList();
            return StatusCode(StatusCodes.Status200OK, lista);
        }

        [HttpPost]
        public async Task<IActionResult> Insertar([FromBody]VMCliente modelo)
        {
            Cliente newModelo = new Cliente()
            {
                Nombre = modelo.Nombre,
                ApellidoPaterno = modelo.ApellidoPaterno,
                ApellidoMaterno = modelo.ApellidoMaterno,
                CantidadPrestada = modelo.CantidadPrestada,
                Telefono = modelo.Telefono,
                Email = modelo.Email,
                FechaPrestamo = modelo.FechaPrestamo,
                DiaCobro = modelo.DiaCobro,
                MesPrestamo = modelo.MesPrestamo,
                Intereses = modelo.Intereses,
            };
            bool asw = await _clienteService.Insertar(newModelo);

            return StatusCode(StatusCodes.Status200OK, new {val = asw});
        }

        [HttpPut]
        public async Task<IActionResult> Actualizar([FromBody] VMCliente modelo)
        {
            Cliente newModelo = new Cliente()
            {
                IdCliente = modelo.IdCliente,
                Nombre = modelo.Nombre,
                ApellidoPaterno = modelo.ApellidoPaterno,
                ApellidoMaterno = modelo.ApellidoMaterno,
                CantidadPrestada = modelo.CantidadPrestada,
                Telefono = modelo.Telefono,
                Email = modelo.Email,
                FechaPrestamo = modelo.FechaPrestamo,
                DiaCobro = modelo.DiaCobro,
                MesPrestamo = modelo.MesPrestamo,
                Intereses = modelo.Intereses,
            };
            bool asw = await _clienteService.Actualizar(newModelo);

            return StatusCode(StatusCodes.Status200OK, new { val = asw });
        }

        [HttpDelete]
        public async Task<IActionResult> Eliminar(int id)
        {            
            bool asw = await _clienteService.Eliminar(id);

            return StatusCode(StatusCodes.Status200OK, new { val = asw });
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}